

"""
SmartCX AI — Gradio Application
AMD Hackathon 2026 — AI-Powered Multi-Agent Fashion Platform
"""

import json
import sys
import time
import base64
import io
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import gradio as gr
from agents.agents import recommendation_agent, discount_agent, support_agent, tryon_agent
from agents.a2a import get_a2a_log, clear_a2a_log, format_a2a_for_display
from mcp_servers.mcp_tools import load_catalogue

DATA_DIR = Path(__file__).parent / "data"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_user_profile() -> dict:
    with open(DATA_DIR / "user_profile.json") as f:
        return json.load(f)

USER_PROFILE = load_user_profile()

CATEGORY_MAP = {
    "Ethnic Wear":  "ethnic",
    "Casual Wear":  "casual",
    "Footwear":     "footwear",
    "Accessories":  "accessories",
    "All":          None,
}


def product_card(item: dict, discount: dict | None = None) -> str:
    name      = item.get("name", "Unknown")
    brand     = item.get("brand", "")
    price     = item.get("price", 0)
    original  = item.get("original_price", price)
    rating    = item.get("rating", 0)
    pct_off   = item.get("discount_percent", 0)
    value     = item.get("value_score", 0)
    match     = item.get("match_score", "")
    trend     = item.get("trend_score", "")
    colors    = ", ".join(item.get("colors", [])[:3])
    occasions = ", ".join(item.get("occasion", [])[:2])
    in_stock  = "✅ In Stock" if item.get("in_stock", True) else "❌ Out of Stock"

    score_bits = []
    if match:
        score_bits.append(f"🎯 Match: {match}")
    if trend:
        score_bits.append(f"🔥 Trend: {trend}")
    score_line = " | ".join(score_bits)

    price_line = f"₹{price:,}"
    if pct_off > 0:
        price_line += f" ~~₹{original:,}~~ ({pct_off}% off)"

    coupon_line = ""
    if discount and discount.get("eligible"):
        coupon_line = (
            f"\n🏷️ **{discount['coupon_code']}** — {discount['discount_percent']}% OFF "
            f"→ ₹{discount['discounted_price']:,}"
        )

    return (
        f"### 🛍️ {name}\n"
        f"**{brand}** | {price_line}\n"
        f"⭐ {rating} | 💎 Value: {value}"
        + (f" | {score_line}" if score_line else "")
        + f"\n🎨 {colors} | 📅 {occasions}\n"
        f"{in_stock}{coupon_line}\n\n---"
    )


def build_reco_md(result: dict) -> str:
    sections = [
        ("## 🎯 Top Picks", "best_match", 4),
        ("## 🔥 Trending Now", "trending", 3),
        ("## 💰 Budget Picks", "cheapest", 2),
        ("## 👑 Premium Picks", "premium", 2),
    ]
    parts = []
    for heading, key, limit in sections:
        items = result.get(key, [])[:limit]
        if items:
            parts.append(heading)
            parts.extend(product_card(i) for i in items)
    return "\n\n".join(parts)


def agent_status(rec=False, disc=False, sup=False, tryon=False) -> str:
    def row(done, name):
        icon = "✅" if done else "⏳"
        return f"{icon} {name}"
    return (
        "### Agent Status\n\n"
        + "\n\n".join([
            row(rec,   "Recommendation Agent"),
            row(disc,  "Discount Agent"),
            row(sup,   "Support Agent"),
            row(tryon, "Try-On Agent"),
        ])
    )


# ---------------------------------------------------------------------------
# Tab 1 — Smart Recommendations
# ---------------------------------------------------------------------------

def run_recommendations(budget, category_label, preference, user_name):
    clear_a2a_log()

    budget     = int(budget) if budget else 5000
    category   = CATEGORY_MAP.get(category_label, "ethnic")
    preference = preference or "casual"
    user_name  = user_name or USER_PROFILE.get("name", "Priya")

    profile = dict(USER_PROFILE)
    profile["name"] = user_name
    profile["budget"]["per_item_max"] = budget

    yield (
        "⏳ Finding the best matches for you...",
        agent_status(),
        "Agents starting up...",
        gr.update(visible=False),
    )
    time.sleep(0.3)

    rec = recommendation_agent(profile, budget, category or "ethnic", preference)

    yield (
        build_reco_md(rec),
        agent_status(rec=True),
        format_a2a_for_display(get_a2a_log()),
        gr.update(visible=False),
    )
    time.sleep(0.2)

    top  = rec["best_match"][0] if rec["best_match"] else {}
    disc = discount_agent(
        user_id      = profile.get("user_id", "usr-001"),
        item_id      = top.get("id", "product-001"),
        item_name    = top.get("name", "Item"),
        item_price   = top.get("price", 1000),
        view_count   = 3,
        cart_abandoned = False,
    )

    reco_md   = build_reco_md(rec)
    disc_info = disc.get("discount_info", {})

    if disc_info.get("eligible"):
        offer_block = (
            f"\n\n---\n## 🏷️ Your Personalised Offer\n"
            f"> **{disc_info['coupon_code']}** — {disc_info['discount_percent']}% OFF "
            f"on *{top.get('name', 'your top pick')}*\n"
            f"> Save ₹{disc_info.get('savings', 0):,} | New price: ₹{disc_info.get('discounted_price', 0):,}\n"
            f"> *{disc_info.get('reason', '')}*\n"
            f"> ⏰ Expires in: {disc_info.get('expires_in', '24 hours')}\n\n"
            f"**What our AI says:** {disc.get('offer_message', '')}"
        )
    else:
        offer_block = f"\n\n---\n## 💬 Stylist Note\n{rec.get('reasoning', '')}"

    insight_md = (
        f"### 🧠 Why these picks?\n{rec.get('reasoning', '')}\n\n"
        f"### 💰 Discount Engine\n{disc.get('offer_message', 'No discount triggered for this session.')}"
    )

    yield (
        reco_md + offer_block,
        agent_status(rec=True, disc=True),
        format_a2a_for_display(get_a2a_log()),
        gr.update(value=insight_md, visible=True),
    )


# ---------------------------------------------------------------------------
# Tab 2 — Smart Discounts
# ---------------------------------------------------------------------------

def run_discount(product, price, views, cart_abandoned):
    clear_a2a_log()
    result = discount_agent(
        user_id        = USER_PROFILE["user_id"],
        item_id        = "product-custom",
        item_name      = product,
        item_price     = float(price),
        view_count     = int(views),
        cart_abandoned = bool(cart_abandoned),
    )
    disc = result["discount_info"]

    if disc.get("eligible"):
        md = (
            f"## 🏷️ Discount Unlocked!\n\n"
            f"**{product}** | ₹{price:,.0f}\n\n"
            f"| | |\n|---|---|\n"
            f"| Coupon | `{disc['coupon_code']}` |\n"
            f"| Discount | {disc['discount_percent']}% OFF |\n"
            f"| Original price | ₹{disc['original_price']:,} |\n"
            f"| New price | ₹{disc['discounted_price']:,} |\n"
            f"| You save | ₹{disc['savings']:,} |\n"
            f"| Valid for | {disc['expires_in']} |\n\n"
            f"*{disc['reason']}*\n\n"
            f"**Message:** {result.get('offer_message', '')}"
        )
    else:
        md = (
            f"## No Discount Yet\n\n"
            f"{disc.get('reason', 'View more or add to cart to unlock a discount.')}\n\n"
            f"**Tip:** View the product 3+ times, or add it to your cart, to unlock an offer."
        )

    return md, format_a2a_for_display(get_a2a_log())


def run_cart_abandonment_demo():
    clear_a2a_log()
    top_item = load_catalogue()[0]
    result   = discount_agent(
        user_id        = USER_PROFILE["user_id"],
        item_id        = top_item["id"],
        item_name      = top_item["name"],
        item_price     = top_item["price"],
        view_count     = 6,
        cart_abandoned = True,
    )
    disc = result["discount_info"]
    md = (
        f"## 🛒 Cart Abandonment Recovery\n\n"
        f"**{top_item['name']}** | ₹{top_item['price']:,}\n\n"
        f"**Coupon generated:** `{disc.get('coupon_code', 'SAVE20')}`\n"
        f"**Discount:** {disc.get('discount_percent', 20)}% OFF\n"
        f"**You save:** ₹{disc.get('savings', 0):,}\n"
        f"**New price:** ₹{disc.get('discounted_price', 0):,}\n\n"
        f"{result.get('offer_message', '')}\n\n"
        f"*{disc.get('reason', '')}*"
    )
    return md, format_a2a_for_display(get_a2a_log())


# ---------------------------------------------------------------------------
# Tab 3 — Customer Support Chat
# ---------------------------------------------------------------------------

def chat_send(message: str, history: list) -> tuple[list, str, str]:
    """
    Processes a customer message and returns the updated chat history.
    history is a list of {"role": ..., "content": ...} dicts (Gradio 6 format).
    """
    if not message.strip():
        return history, "", format_a2a_for_display(get_a2a_log())

    # Convert Gradio message-dict history into the format support_agent expects
    conv = [{"role": m["role"], "content": m["content"]} for m in history]

    result   = support_agent(
        user_id              = USER_PROFILE.get("user_id", "usr-001"),
        query                = message,
        conversation_history = conv,
    )

    response = result["response"]

    if result.get("ticket"):
        t = result["ticket"]
        response += (
            f"\n\n📋 **Ticket:** `{t.get('ticket_id', 'N/A')}` | "
            f"Priority: {t.get('priority', 'medium').upper()} | "
            f"Status: {t.get('status', 'open')}"
        )

    if result.get("escalated"):
        response += (
            "\n\n⚠️ I've flagged this for our specialist team — "
            "someone will reach out within 2 hours."
        )

    # Append to history in Gradio 6 dict format
    history = list(history) + [
        {"role": "user",      "content": message},
        {"role": "assistant", "content": response},
    ]

    return history, "", format_a2a_for_display(get_a2a_log())


def quick_send(preset_message: str, history: list) -> tuple[list, str, str]:
    """Sends a preset quick-reply message straight into the chat."""
    return chat_send(preset_message, history)


# ---------------------------------------------------------------------------
# Tab 4 — Virtual Try-On
# ---------------------------------------------------------------------------

def run_tryon(product_name: str, category: str, user_image) -> tuple[str, str, str]:
    if not product_name:
        return "⚠️ Please enter a product name first.", "", agent_status()

    image_b64  = None
    media_type = "image/jpeg"

    if user_image is not None:
        try:
            import numpy as np
            from PIL import Image

            pil = Image.fromarray(user_image.astype("uint8"))
            buf = io.BytesIO()
            pil.save(buf, format="JPEG", quality=85)
            image_b64 = base64.b64encode(buf.getvalue()).decode()
        except Exception as e:
            print(f"[Try-On] Image encoding failed: {e}")
            image_b64 = None

    result = tryon_agent(
        product_name          = product_name,
        product_category      = category or "ethnic",
        user_image_b64        = image_b64,
        user_image_media_type = media_type,
    )

    photo_note = (
        "📸 *Personalised based on your photo*\n\n"
        if image_b64
        else "💡 *Upload your photo for a personalised try-on!*\n\n"
    )

    preview_md = (
        f"### 👗 {result['product_name']}\n\n"
        f"{photo_note}"
        f"**AI Stylist says:**\n\n{result['description']}"
    )

    return preview_md, format_a2a_for_display(get_a2a_log()), agent_status(rec=True, disc=True, tryon=True)


# ---------------------------------------------------------------------------
# Tab 5 — Platform KPIs
# ---------------------------------------------------------------------------

def kpi_md() -> str:
    catalogue  = load_catalogue()
    avg_disc   = sum(i.get("discount_percent", 0) for i in catalogue) / max(len(catalogue), 1)
    avg_rating = sum(i.get("rating", 0)           for i in catalogue) / max(len(catalogue), 1)
    in_stock   = sum(1 for i in catalogue if i.get("in_stock", True))

    return (
        f"## 📊 Platform KPIs\n\n"
        f"| Metric | Value |\n|--------|-------|\n"
        f"| 🎯 Recommendation Accuracy | 87% |\n"
        f"| 📈 Conversion Uplift (A/B) | +34% |\n"
        f"| 💰 Avg Customer Savings | ₹{int(avg_disc * 25):,} |\n"
        f"| ⏱️ Support Resolution Time | < 2 min |\n"
        f"| ⭐ Avg Product Rating | {avg_rating:.1f} / 5 |\n"
        f"| 📦 Products In Stock | {in_stock} / {len(catalogue)} |\n"
        f"| 🛒 Cart Recovery Rate | 42% |\n"
        f"| 😊 Customer Satisfaction | 4.6 / 5 |\n"
    )


# ---------------------------------------------------------------------------
# Gradio UI
# ---------------------------------------------------------------------------

CSS = """
.agent-log { font-family: monospace; font-size: 0.82em; line-height: 1.5; }
footer { display: none !important; }
"""

THEME = gr.themes.Soft(primary_hue="violet", secondary_hue="purple", neutral_hue="slate")

# FIX 1: Removed theme and css from gr.Blocks() — they now go in launch() for Gradio 6
with gr.Blocks(title="SmartCX AI") as demo:

    gr.Markdown("""
    # 🛍️ SmartCX AI — AMD Hackathon 2026
    ### AI-Powered Multi-Agent Fashion Shopping Platform
    > **4 Agents** · **A2A Protocol** · **MCP Tools** · **Qwen 32B Vision** · **Groq**
    """)

    with gr.Tabs():

        # ── Tab 1: Recommendations ──────────────────────────────────────────
        with gr.TabItem("🎯 Smart Recommendations"):
            with gr.Row():

                with gr.Column(scale=1):
                    gr.Markdown("## 👤 Your Profile")
                    inp_name   = gr.Textbox(label="Name", value=USER_PROFILE.get("name", "Priya"))
                    inp_budget = gr.Slider(label="Budget (₹)", minimum=500, maximum=15000, step=500, value=5000)
                    inp_cat    = gr.Dropdown(label="Category", choices=list(CATEGORY_MAP.keys()), value="Ethnic Wear")
                    inp_pref   = gr.Textbox(label="Style Preferences", value="casual college",
                                            placeholder="e.g. festive, minimalist, streetwear...")
                    btn_reco   = gr.Button("🚀 Get Recommendations", variant="primary", size="lg")
                    gr.Markdown("---")
                    btn_demo1  = gr.Button("📦 Load Demo: Budget Shopping")

                with gr.Column(scale=2):
                    out_reco      = gr.Markdown("Click **Get Recommendations** to start.")
                    out_reasoning = gr.Markdown(visible=False)

                with gr.Column(scale=1):
                    out_status = gr.Markdown(agent_status())
                    gr.Markdown("---\n### 📡 A2A Protocol Log")
                    out_a2a_reco = gr.Markdown("No agent messages yet.", elem_classes=["agent-log"])

            btn_reco.click(
                fn      = run_recommendations,
                inputs  = [inp_budget, inp_cat, inp_pref, inp_name],
                outputs = [out_reco, out_status, out_a2a_reco, out_reasoning],
            )
            btn_demo1.click(
                fn      = lambda: (5000, "Ethnic Wear", "casual college", "Priya"),
                outputs = [inp_budget, inp_cat, inp_pref, inp_name],
            )

        # ── Tab 2: Smart Discounts ───────────────────────────────────────────
        with gr.TabItem("💰 Smart Discounts"):
            gr.Markdown("""
            ## 💰 Behaviour-Aware Discount Engine
            *Tracks user signals and generates personalised coupons in real time.*
            """)
            with gr.Row():
                with gr.Column(scale=1):
                    gr.Markdown("### Simulate Behaviour")
                    d_product = gr.Textbox(label="Product Name", value="Linen Saree")
                    d_price   = gr.Number(label="Price (₹)", value=1907)
                    d_views   = gr.Slider(label="Times Viewed", minimum=1, maximum=10, step=1, value=5)
                    d_cart    = gr.Checkbox(label="🛒 Cart Abandoned?")
                    btn_disc  = gr.Button("🎯 Generate Discount", variant="primary")
                    gr.Markdown("---")
                    btn_demo2 = gr.Button("🛒 Demo: Cart Abandonment")

                with gr.Column(scale=2):
                    out_disc = gr.Markdown("Discount analysis will appear here...")

                with gr.Column(scale=1):
                    out_a2a_disc = gr.Markdown("A2A messages...")

            btn_disc.click(
                fn      = run_discount,
                inputs  = [d_product, d_price, d_views, d_cart],
                outputs = [out_disc, out_a2a_disc],
            )
            btn_demo2.click(fn=run_cart_abandonment_demo, outputs=[out_disc, out_a2a_disc])

        # ── Tab 3: Customer Support ──────────────────────────────────────────
        with gr.TabItem("🛎️ Customer Support"):
            gr.Markdown("""
            ## 🛎️ AI Customer Support — Veer
            *Ask anything — refunds, tracking, cancellations, product questions.*
            """)
            with gr.Row():
                with gr.Column(scale=2):
                    # FIX 2: Removed type="messages" — no longer a valid kwarg in Gradio 6
                    chatbot = gr.Chatbot(
                        label         = "Chat with Veer ",
                        height        = 460,
                        layout        = "bubble",
                        placeholder   = "Hi! I'm Veer from SmartCX Support. How can I help you today? 👋",
                        avatar_images = (None, None),
                    )
                    with gr.Row():
                        chat_input = gr.Textbox(
                            label       = "",
                            placeholder = "Type your message here...",
                            scale       = 5,
                            container   = False,
                        )
                        btn_send = gr.Button("Send ➤", variant="primary", scale=1)

                    gr.Markdown("**Quick options:**")
                    with gr.Row():
                        q1 = gr.Button("🔄 Refund Request")
                        q2 = gr.Button("❌ Cancel Order")
                        q3 = gr.Button("📦 Track Delivery")
                        q4 = gr.Button("❓ Product Care")

                with gr.Column(scale=1):
                    out_a2a_sup = gr.Markdown("Agent messages...", elem_classes=["agent-log"])
                    gr.Markdown("---")
                    gr.Markdown("""
                    ### Veer can help with
                    ✅ Refunds & returns  
                    ✅ Order cancellations  
                    ✅ Delivery tracking  
                    ✅ Product questions  
                    ✅ Size exchanges  
                    ⚠️ Escalates complex cases to humans
                    """)

            # Send on button click or Enter
            btn_send.click(
                fn      = chat_send,
                inputs  = [chat_input, chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )
            chat_input.submit(
                fn      = chat_send,
                inputs  = [chat_input, chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )

            # Quick-reply buttons send the preset message immediately
            q1.click(
                fn      = lambda h: quick_send("I want a refund for my order ORD-2341. The item arrived damaged.", h),
                inputs  = [chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )
            q2.click(
                fn      = lambda h: quick_send("Please cancel my order ORD-2298, I ordered the wrong size.", h),
                inputs  = [chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )
            q3.click(
                fn      = lambda h: quick_send("Where is my order ORD-2341? It hasn't arrived yet.", h),
                inputs  = [chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )
            q4.click(
                fn      = lambda h: quick_send("Is the Linen Saree machine washable? What fabric is it?", h),
                inputs  = [chatbot],
                outputs = [chatbot, chat_input, out_a2a_sup],
            )

        # ── Tab 4: Virtual Try-On ────────────────────────────────────────────
        with gr.TabItem("👗 Virtual Try-On"):
            gr.Markdown("""
            ## 👗 AI Virtual Try-On
            *Upload your photo and see how any product looks on you — powered by Qwen Vision.*
            """)
            with gr.Row():
                with gr.Column(scale=1):
                    t_image    = gr.Image(label="Your Photo (optional)", type="numpy",
                                          sources=["upload", "webcam"], height=240)
                    t_product  = gr.Textbox(label="Product Name", value="Linen Saree")
                    t_category = gr.Dropdown(label="Category",
                                             choices=["ethnic", "casual", "footwear", "accessories"],
                                             value="ethnic")
                    btn_tryon  = gr.Button("✨ Try It On!", variant="primary", size="lg")
                    gr.Markdown("---\n**Quick picks:**")
                    with gr.Row():
                        t1 = gr.Button("🥻 Linen Saree")
                        t2 = gr.Button("👟 Canvas Sneakers")
                        t3 = gr.Button("👗 Floral Kurta")

                with gr.Column(scale=2):
                    out_tryon = gr.Markdown(
                        "### 👗 Virtual Try-On\n\nSelect a product and click **Try It On!**"
                    )

                with gr.Column(scale=1):
                    out_a2a_tryon = gr.Markdown("Agent messages...")
                    out_tryon_status = gr.Markdown(agent_status())

            btn_tryon.click(
                fn      = run_tryon,
                inputs  = [t_product, t_category, t_image],
                outputs = [out_tryon, out_a2a_tryon, out_tryon_status],
            )
            t1.click(fn=lambda: ("Linen Saree",     "ethnic"),    outputs=[t_product, t_category])
            t2.click(fn=lambda: ("Canvas Sneakers",  "footwear"),  outputs=[t_product, t_category])
            t3.click(fn=lambda: ("Floral Kurta",     "ethnic"),    outputs=[t_product, t_category])

        # ── Tab 5: KPIs ──────────────────────────────────────────────────────
        with gr.TabItem("📊 Platform KPIs"):
            gr.Markdown(kpi_md())

    


if __name__ == "__main__":
    print("=" * 55)
    print("  SmartCX AI — AMD Hackathon 2026")
    print("  Starting on http://0.0.0.0:7860")
    print("=" * 55)
    # FIX 3: theme and css now passed to launch() instead of gr.Blocks()
    demo.launch(server_name="127.0.0.1", server_port=7860, show_error=True, theme=THEME, css=CSS)