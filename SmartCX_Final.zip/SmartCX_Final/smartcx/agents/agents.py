"""
SmartCX AI — Agent Definitions
Four agents that work together to deliver a personalized shopping experience.
"""

import json
import re
import sys
import random
import base64
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp_servers.mcp_tools import (
    search_products, recommend_products, get_trending_products,
    check_discount, get_user_behavior_summary,
    get_refund_status, cancel_order, create_support_ticket,
)
from agents.a2a import send_a2a_message, get_a2a_log

import requests

# ---------------------------------------------------------------------------
# Groq API — Qwen QwQ 32B
# ---------------------------------------------------------------------------

GROQ_API_KEY = "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"
GROQ_URL     = "https://api.groq.com/openai/v1/chat/completions"
MODEL        = "qwen-qwq-32b"


def _ask_groq(messages: list, max_tokens: int = 600) -> str | None:
    """
    Send a list of OpenAI-style messages to Groq and return the reply text.
    Returns None if the call fails for any reason.
    """
    try:
        resp = requests.post(
            GROQ_URL,
            headers={
                "Authorization": f"Bearer {GROQ_API_KEY}",
                "Content-Type": "application/json",
            },
            json={"model": MODEL, "max_tokens": max_tokens, "messages": messages},
            timeout=30,
        )
        if resp.status_code == 200:
            text = resp.json()["choices"][0]["message"]["content"].strip()
            # Qwen QwQ sometimes wraps its reasoning in <think> tags — strip those
            text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
            return text or None
        print(f"[Groq {resp.status_code}] {resp.text[:200]}")
    except Exception as exc:
        print(f"[Groq error] {exc}")
    return None


def _chat(system: str, user: str, max_tokens: int = 600) -> str:
    """Simple single-turn chat. Falls back to a smart local reply on failure."""
    result = _ask_groq(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        max_tokens,
    )
    return result if result else _local_reply(system, user)


def _chat_with_history(system: str, history: list[dict], max_tokens: int = 500) -> str | None:
    """
    Multi-turn chat that keeps the conversation context.
    `history` is a list of {"role": ..., "content": ...} dicts (not including system).
    Returns None on failure so the caller can use its own fallback.
    """
    return _ask_groq([{"role": "system", "content": system}] + history, max_tokens)


def _vision_chat(system: str, text: str, image_b64: str,
                 media_type: str = "image/jpeg", max_tokens: int = 600) -> str:
    """Vision call. Falls back to text-only if Groq doesn't support images."""
    result = _ask_groq(
        [
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": [
                    {"type": "image_url",
                     "image_url": {"url": f"data:{media_type};base64,{image_b64}"}},
                    {"type": "text", "text": text},
                ],
            },
        ],
        max_tokens,
    )
    if result:
        return result
    # Fall back to text-only description
    return _chat(system, text, max_tokens)


# ---------------------------------------------------------------------------
# Local fallback replies  (used when Groq is unreachable)
# ---------------------------------------------------------------------------

def _local_reply(system: str, user: str) -> str:
    """
    Picks the right fallback based on which agent is calling.
    Checks the system prompt for agent-specific keywords.
    """
    sys_lower = system.lower()

    # Support agent — MUST be checked before "fashion" to avoid misrouting
    if any(k in sys_lower for k in ("support", "empathetic", "smartcx customer", "refund/return")):
        return _support_reply(user.lower())

    # Recommendation agent
    if any(k in sys_lower for k in ("recommendation", "shopping insight", "fashion stylist pick")):
        trending = random.choice(["linen sarees", "coord sets", "floral kurtas", "block-print shirts"])
        return (
            f"I've pulled together some picks that really suit your style and budget. "
            f"The top match hits everything on your list — the fit, the occasion, the price. "
            f"Also worth a look: {trending} are really popular right now for your age group. "
            f"I've thrown in a couple of budget-friendly and premium options too, just so you have choices. 🛍️"
        )

    # Discount agent
    if any(k in sys_lower for k in ("discount", "coupon", "behavior signal", "offer message")):
        pct  = random.choice([10, 15, 20])
        code = random.choice(["SAVE15", "VIEW10", "CART20", "SMARTCX"])
        return (
            f"Looks like you've had your eye on this one for a bit — totally get it, it's a great pick! "
            f"We're unlocking {pct}% off just for you. Use **{code}** at checkout. "
            f"Offer's live for the next 24 hours, so don't let it slip. 🎉"
        )

    # Try-on agent
    if any(k in sys_lower for k in ("fashion stylist", "try on", "body type", "drape")):
        return _tryon_reply()

    return "Happy to help — could you tell me a bit more about what you're looking for?"


def _support_reply(user_lower: str) -> str:
    """Context-aware support replies that sound like a real person wrote them."""

    order_match = re.search(r"ord-?\d+", user_lower)
    order_ref   = order_match.group(0).upper() if order_match else "your order"

    if any(w in user_lower for w in ("refund", "return", "money back", "damaged", "reimburse")):
        return (
            f"Oh no, I'm really sorry about that — a damaged item is so frustrating. "
            f"Good news: {order_ref} is within our 7-day return window, so you're fully covered. "
            f"I've flagged it as high priority and our team will process the refund within 3–5 business days. "
            f"You'll get a confirmation email soon. Anything else I can sort out for you?"
        )

    if any(w in user_lower for w in ("cancel", "cancellation")):
        return (
            f"Done — I've put the cancellation through for {order_ref}. "
            f"Your refund will land back in your original payment method within 3–5 business days. "
            f"A confirmation is on its way to your registered email. "
            f"Is there anything else I can help with?"
        )

    if any(w in user_lower for w in ("track", "delivery", "shipping", "where", "arrive", "status", "reached")):
        return (
            f"I just checked on {order_ref} — it's out for delivery and on its way to you! "
            f"You should have it within the next 2 business days. "
            f"We'll send you an SMS the moment it's at your door. "
            f"If it still hasn't shown up after that, ping me and I'll escalate it straight away."
        )

    if any(w in user_lower for w in ("exchange", "wrong size", "swap", "size")):
        return (
            "Totally fine — size mix-ups happen! "
            "Drop your order ID and the size you actually need, and I'll get the exchange going right away. "
            "Exchanges are free within 7 days of delivery, so you're in good time."
        )

    if any(w in user_lower for w in ("wash", "fabric", "material", "care", "machine washable")):
        return (
            "Great question! Most of our ethnic wear uses natural fabrics — linen, cotton, and silk blends. "
            "For best results, go with a gentle hand wash or a delicate cold-water machine cycle. "
            "The care label on the garment will have the exact instructions specific to that piece. "
            "Anything else I can help you with?"
        )

    if any(w in user_lower for w in ("discount", "coupon", "offer", "promo", "deal")):
        return (
            "Happy to help you save! "
            "You get 10% off after viewing a product 3+ times, and 20% off if you've left something in your cart. "
            "The Smart Discounts tab also shows your personalised offers. "
            "Anything specific you're eyeing?"
        )

    if any(w in user_lower for w in ("hello", "hi", "hey", "start", "help")):
        return (
            "Hey there! Welcome to SmartCX Support 👋 "
            "I'm here to help with refunds, delivery tracking, cancellations, product questions — you name it. "
            "What can I help you with today?"
        )

    # Generic fallback
    return (
        "Thanks for reaching out! I want to make sure I get this right for you. "
        "I've logged your query and created a support ticket — our team will follow up within 24 hours. "
        "Could you share a bit more detail so I can dig into this properly?"
    )


def _tryon_reply() -> str:
    fabric = random.choice(["linen", "cotton", "silk-blend", "chiffon"])
    colour = random.choice(["sage green", "dusty rose", "teal", "mustard yellow", "off-white"])
    return (
        f"This is going to look really lovely on you! "
        f"The {fabric} drapes beautifully and gives a relaxed, put-together feel. "
        f"The {colour} tone would complement your skin really well and bring the whole look to life. "
        f"It's the kind of outfit that works for college, a café catch-up, or a festive gathering equally well. ✨"
    )


# ---------------------------------------------------------------------------
# Agent 1 — Recommendation Agent
# ---------------------------------------------------------------------------

def recommendation_agent(user_profile: dict, budget: int, category: str, preferences: str) -> dict:
    """
    Searches the catalogue, scores products against the user's profile,
    then uses Qwen to write a warm personalised summary.
    """
    slim_profile = {
        "budget": {"per_item_max": budget},
        "style_preferences": {
            "categories": [category.lower()] if category else ["ethnic"],
            "occasions":  [preferences.lower()],
            "favorite_colors": user_profile.get("style_preferences", {}).get("favorite_colors", []),
        },
    }

    reco_data  = recommend_products(slim_profile, limit=6)
    age_group  = user_profile.get("age_group", "18-24")
    trending   = get_trending_products(age_group=age_group, limit=4)

    top_picks = "\n".join(
        f"- {p['name']} by {p['brand']}, ₹{p['price']}, "
        f"rated {p.get('rating', 0)}/5, match score {p.get('match_score', 0)}"
        for p in reco_data["best_match"][:4]
    )
    trending_names = ", ".join(t["name"] for t in trending[:3])

    system = (
        "You are a friendly fashion shopping assistant. "
        "Write a warm, natural 3–4 sentence message to the customer about their recommendations. "
        "Mention the top pick, why it suits them, and one trending item. "
        "Talk like a knowledgeable friend, not a sales bot. Use 'you/your'. "
        "Reply with just the message — no headers, no bullet points, no reasoning."
    )
    user_msg = (
        f"Customer: {user_profile.get('name', 'there')}, "
        f"age {user_profile.get('age', 22)}, budget ₹{budget}, looking for {preferences} {category}.\n\n"
        f"Best matching products:\n{top_picks}\n\n"
        f"Trending for age group {age_group}: {trending_names}"
    )

    insight = _chat(system, user_msg, max_tokens=300)

    top = reco_data["best_match"][0] if reco_data["best_match"] else {}
    send_a2a_message(
        from_agent="🎯 Recommendation Agent",
        to_agent="💰 Discount Agent",
        payload={
            "product":       top.get("name", "N/A"),
            "product_id":    top.get("id", ""),
            "price":         top.get("price", 0),
            "interest_score": int(top.get("match_score", 0)),
            "user_id":       user_profile.get("user_id", "usr-001"),
        },
        msg_type="recommendation_completed",
    )

    return {
        "best_match": reco_data["best_match"],
        "trending":   trending,
        "cheapest":   reco_data["cheapest_alternatives"],
        "premium":    reco_data["premium_picks"],
        "reasoning":  insight,
        "agent":      "Recommendation Agent",
        "status":     "✅ Completed",
    }


# ---------------------------------------------------------------------------
# Agent 2 — Discount Agent
# ---------------------------------------------------------------------------

def discount_agent(user_id: str, item_id: str, item_name: str, item_price: float,
                   view_count: int = 1, cart_abandoned: bool = False) -> dict:
    """
    Checks whether the user qualifies for a discount based on their behaviour,
    then writes a personalised nudge message.
    """
    behavior     = get_user_behavior_summary(user_id)
    discount_info = check_discount(
        user_id=user_id, item_id=item_id,
        item_price=item_price, view_count=view_count, cart_abandoned=cart_abandoned,
    )

    signals = []
    if cart_abandoned:
        signals.append("left it in their cart")
    if view_count >= 3:
        signals.append(f"viewed it {view_count} times")
    signals.append(f"engagement level: {behavior.get('intent_level', 'medium')}")

    system = (
        "You are a friendly shopping assistant sending a personalised offer to a customer. "
        "Write 2–3 natural sentences that feel warm and human — not pushy. "
        "Acknowledge what they were looking at and offer the deal in a low-key, genuine way. "
        "Just the message — no reasoning, no lists."
    )
    user_msg = (
        f"Product: {item_name} (₹{item_price:.0f})\n"
        f"Customer behaviour: {', '.join(signals)}\n"
        f"Discount available: {discount_info.get('discount_percent', 0)}% off\n"
        f"Coupon code: {discount_info.get('coupon_code', 'N/A')}"
    )

    offer_msg = _chat(system, user_msg, max_tokens=200)

    send_a2a_message(
        from_agent="💰 Discount Agent",
        to_agent="🎯 Recommendation Agent",
        payload={
            "coupon":           discount_info.get("coupon_code"),
            "discount_percent": discount_info.get("discount_percent"),
            "eligible":         discount_info.get("eligible"),
            "product":          item_name,
        },
        msg_type="discount_generated",
    )

    return {
        "discount_info":    discount_info,
        "behavior_summary": behavior,
        "offer_message":    offer_msg,
        "agent":            "Discount Agent",
        "status":           "✅ Completed",
    }


# ---------------------------------------------------------------------------
# Agent 3 — Customer Support Agent
# ---------------------------------------------------------------------------

def support_agent(user_id: str, query: str, conversation_history: list | None = None) -> dict:
    """
    Handles customer queries — refunds, cancellations, delivery, product questions.
    Passes full chat history to Qwen so multi-turn conversations feel natural.
    Escalates to a human agent for complex queries.
    """
    q = query.lower()
    is_refund   = any(w in q for w in ("refund", "return", "money back", "reimburse", "damaged"))
    is_cancel   = any(w in q for w in ("cancel", "cancellation"))
    is_delivery = any(w in q for w in ("delivery", "shipping", "track", "where is", "arrive", "reached"))

    ticket_result = None
    mcp_data      = {}

    # Pull real order data from MCP tools
    if is_refund or is_cancel:
        match    = re.search(r"ORD-\d+", query.upper())
        order_id = match.group(0) if match else f"ORD-{2000 + abs(hash(query)) % 999}"
        if is_refund:
            mcp_data = get_refund_status(order_id)
        if is_cancel:
            mcp_data      = cancel_order(order_id, reason="customer_request")
            ticket_result = mcp_data

    if not ticket_result and (is_refund or is_delivery):
        ticket_result = create_support_ticket(
            user_id=user_id,
            issue_type="refund" if is_refund else "delivery",
            description=query,
            product=None,
        )

    # Embed any real order data into the system prompt so Qwen can reference it
    order_context = ""
    if mcp_data:
        order_context += f"\n\nReal order data from our system: {json.dumps(mcp_data)}"
    if ticket_result and ticket_result is not mcp_data:
        order_context += f"\nSupport ticket just created: {json.dumps(ticket_result)}"

    system = (
        "You are Maya, a warm and helpful customer support agent at SmartCX — a fashion shopping platform. "
        "You genuinely care about solving the customer's problem. "
        "Keep replies conversational, empathetic, and concise (3–5 sentences). "
        "For refunds: confirm the 7-day return window and next steps. "
        "For deliveries: confirm the status and expected arrival. "
        "For cancellations: confirm it's done and the 3–5 day refund timeline. "
        "For product questions: give honest, helpful info about the item. "
        "If something is beyond your ability to resolve right now, promise a follow-up from a specialist. "
        "Never write in bullet points. Never include reasoning or chain-of-thought — just reply naturally."
        + order_context
    )

    # Build the conversation history Groq will see
    history_for_groq = []
    if conversation_history:
        for turn in conversation_history[-6:]:
            role    = turn.get("role", "user")
            content = turn.get("content", "")
            if content:
                history_for_groq.append({"role": role, "content": content})
    history_for_groq.append({"role": "user", "content": query})

    # Try Groq first; fall back to our local smart replies
    response = _chat_with_history(system, history_for_groq, max_tokens=400)
    if not response:
        response = _support_reply(q)

    # Decide confidence and whether to escalate
    confidence = 0.85 if (is_refund or is_cancel or is_delivery) else 0.65
    escalated  = confidence < 0.70

    if escalated:
        ticket_result = create_support_ticket(
            user_id=user_id, issue_type="general", description=query
        )
        send_a2a_message(
            from_agent="🛎️ Support Agent",
            to_agent="👤 Human Support",
            payload={
                "ticket_id": ticket_result.get("ticket_id"),
                "reason":    "Needs human review",
                "query":     query[:100],
                "user_id":   user_id,
            },
            msg_type="escalation",
        )
    else:
        send_a2a_message(
            from_agent="🛎️ Support Agent",
            to_agent="🎯 Recommendation Agent",
            payload={
                "issue_resolved": True,
                "issue_type":     "refund" if is_refund else ("cancel" if is_cancel else "general"),
                "user_id":        user_id,
            },
            msg_type="support_resolved",
        )

    return {
        "response":   response,
        "ticket":     ticket_result,
        "mcp_data":   mcp_data,
        "confidence": confidence,
        "escalated":  escalated,
        "agent":      "Support Agent",
        "status":     "⚠️ Escalated to Human" if escalated else "✅ Resolved",
    }


# ---------------------------------------------------------------------------
# Agent 4 — Virtual Try-On Agent
# ---------------------------------------------------------------------------

def tryon_agent(product_name: str, product_category: str,
                user_image_b64: str | None = None,
                user_image_media_type: str = "image/jpeg") -> dict:
    """
    Describes how a product would look on the customer.
    If a photo is provided, Qwen Vision gives a personalised description.
    """
    system = (
        "You are an enthusiastic fashion stylist helping someone picture themselves in an outfit. "
        "If you can see a photo of the person, describe specifically how this item would look on them — "
        "their build, colouring, overall vibe. If no photo, paint a vivid general picture. "
        "Be warm, encouraging, and specific. 4–5 sentences max. "
        "No reasoning, no bullet points — just your styling take."
    )

    if user_image_b64:
        user_msg = (
            f"The person in this photo is trying on: {product_name} ({product_category}). "
            f"Look at them carefully and describe how this piece would look on them specifically."
        )
        description = _vision_chat(system, user_msg, user_image_b64, user_image_media_type, max_tokens=350)
    else:
        user_msg = (
            f"Product: {product_name} (category: {product_category}). "
            f"Describe how this would look when worn — fabrics, drape, occasions it suits."
        )
        description = _chat(system, user_msg, max_tokens=300)

    send_a2a_message(
        from_agent="👗 Try-On Agent",
        to_agent="💰 Discount Agent",
        payload={
            "product":         product_name,
            "try_on_completed": True,
            "used_photo":      user_image_b64 is not None,
            "engagement":      "high",
            "action":          "request_purchase_nudge",
        },
        msg_type="tryon_completed",
    )

    return {
        "description":  description,
        "product_name": product_name,
        "agent":        "Try-On Agent",
        "status":       "✅ Preview Ready",
        "used_photo":   user_image_b64 is not None,
    }
