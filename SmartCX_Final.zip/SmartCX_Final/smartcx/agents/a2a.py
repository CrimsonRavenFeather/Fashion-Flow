"""
A2A Protocol — Agent-to-Agent Communication Layer
All inter-agent messages are logged and returned for UI display.
"""

import json
import uuid
from datetime import datetime
from typing import List, Dict, Any

# In memory A2A message bus (visible in UI)
_a2a_log: List[Dict] = []


def send_a2a_message(from_agent: str, to_agent: str, payload: dict, msg_type: str = "data") -> str:
    """Send a message from one agent to another via A2A protocol."""
    msg_id = f"A2A-{uuid.uuid4().hex[:8].upper()}"
    message = {
        "msg_id": msg_id,
        "from": from_agent,
        "to": to_agent,
        "type": msg_type,
        "payload": payload,
        "timestamp": datetime.utcnow().strftime("%H:%M:%S"),
    }
    _a2a_log.append(message)
    return msg_id


def get_a2a_log() -> List[Dict]:
    """Return all A2A messages for UI display."""
    return list(_a2a_log)


def clear_a2a_log():
    """Clear log for a new session."""
    _a2a_log.clear()


def format_a2a_for_display(messages: List[Dict]) -> str:
    """Format A2A messages as readable log string."""
    if not messages:
        return "No agent communications yet."
    lines = []
    for msg in messages:
        payload_str = json.dumps(msg["payload"], ensure_ascii=False)
        if len(payload_str) > 120:
            payload_str = payload_str[:120] + "..."
        lines.append(
            f"[{msg['timestamp']}] {msg['from']} → {msg['to']}\n"
            f"  Type: {msg['type']}\n"
            f"  Payload: {payload_str}"
        )
    return "\n\n".join(lines)
