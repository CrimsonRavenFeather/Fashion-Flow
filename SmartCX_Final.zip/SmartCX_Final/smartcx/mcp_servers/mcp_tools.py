"""
MCP Tool Servers for SmartCX AI
Provides tool interfaces for all 4 agents.
"""

import json
import uuid
import random
from pathlib import Path
from datetime import datetime

DATA_DIR = Path(__file__).parent.parent / "data"


# ══════════════════════════════════════════════════════════
# PRODUCT CATALOG MCP
# ══════════════════════════════════════════════════════════

def load_catalogue():
    with open(DATA_DIR / "catalogue.json", "r") as f:
        data = json.load(f)
    return data.get("items", [])


def search_products(category: str = None, max_price: int = None,
                    gender: str = None, occasion: str = None,
                    style: str = None, limit: int = 10) -> list:
    """MCP Tool: Search products by filters."""
    items = load_catalogue()
    results = []
    for item in items:
        if category and item.get("category", "").lower() != category.lower():
            # Also check sub_category
            if item.get("sub_category", "").lower() != category.lower():
                continue
        if max_price and item.get("price", 0) > max_price:
            continue
        if gender and gender.lower() not in ["unisex", item.get("gender", "").lower()]:
            if item.get("gender", "").lower() != "unisex":
                continue
        if occasion and occasion.lower() not in [o.lower() for o in item.get("occasion", [])]:
            continue
        if style and style.lower() not in [t.lower() for t in item.get("trend_tags", [])]:
            continue
        results.append(item)
    # Sort by value_score desc
    results.sort(key=lambda x: (x.get("value_score", 0), x.get("rating", 0)), reverse=True)
    return results[:limit]


def recommend_products(user_profile: dict, limit: int = 6) -> dict:
    """MCP Tool: Recommend products based on user profile."""
    budget = user_profile.get("budget", {}).get("per_item_max", 5000)
    categories = user_profile.get("style_preferences", {}).get("categories", [])
    occasions = user_profile.get("style_preferences", {}).get("occasions", [])
    colors = user_profile.get("style_preferences", {}).get("favorite_colors", [])

    items = load_catalogue()
    scored = []
    for item in items:
        if not item.get("in_stock", True):
            continue
        score = 0
        if item.get("price", 9999) <= budget:
            score += 30
        if item.get("category", "") in categories:
            score += 25
        for occ in item.get("occasion", []):
            if occ in occasions:
                score += 15
                break
        for color in item.get("colors", []):
            if color in colors:
                score += 10
                break
        score += item.get("rating", 0) * 3
        score += item.get("value_score", 0) * 2
        item["match_score"] = round(score, 1)
        scored.append(item)

    scored.sort(key=lambda x: x["match_score"], reverse=True)
    best = scored[:limit]

    # Find cheapest & premium alternatives
    all_sorted_price = sorted([i for i in items if i.get("in_stock", True)],
                              key=lambda x: x.get("price", 0))
    cheapest = all_sorted_price[:3] if all_sorted_price else []
    premium = sorted(all_sorted_price, key=lambda x: x.get("rating", 0), reverse=True)[:3]

    return {
        "best_match": best,
        "cheapest_alternatives": cheapest,
        "premium_picks": premium
    }


# ══════════════════════════════════════════════════════════
# TREND MCP
# ══════════════════════════════════════════════════════════

def get_trending_products(age_group: str = "18-24", limit: int = 5) -> list:
    """MCP Tool: Get trending products for age group."""
    with open(DATA_DIR / "trends.json", "r") as f:
        trends_data = json.load(f)

    age_trends = trends_data.get("trends_by_age_group", {}).get(age_group, {})
    trending_items = age_trends.get("trending_items", [])
    trending_styles = age_trends.get("top_styles", [])
    trending_colors = age_trends.get("trending_colors", [])

    catalogue = load_catalogue()
    results = []
    for item in catalogue:
        if not item.get("in_stock", True):
            continue
        trend_score = 0
        if item.get("id") in trending_items:
            trend_score += 50
        for tag in item.get("trend_tags", []):
            if tag in trending_styles:
                trend_score += 20
        for color in item.get("colors", []):
            if color in trending_colors:
                trend_score += 10
        if trend_score > 0:
            item["trend_score"] = trend_score
            results.append(item)

    results.sort(key=lambda x: x.get("trend_score", 0), reverse=True)
    return results[:limit]


# ══════════════════════════════════════════════════════════
# USER BEHAVIOR MCP
# ══════════════════════════════════════════════════════════

def check_discount(user_id: str, item_id: str, item_price: float,
                   view_count: int = 1, cart_abandoned: bool = False) -> dict:
    """MCP Tool: Check if user qualifies for a discount."""
    discount = None
    coupon_code = None
    reason = None

    if cart_abandoned:
        discount = 20
        coupon_code = "SAVE20"
        reason = "Cart abandonment detected — special recovery offer"
    elif view_count >= 5:
        discount = 15
        coupon_code = f"VIEW15-{item_id[-3:].upper()}"
        reason = f"Viewed {view_count} times — loyalty discount"
    elif view_count >= 3:
        discount = 10
        coupon_code = f"REPEAT10"
        reason = "Repeat visitor discount"

    if discount:
        discounted_price = round(item_price * (1 - discount / 100))
        return {
            "eligible": True,
            "discount_percent": discount,
            "coupon_code": coupon_code,
            "original_price": item_price,
            "discounted_price": discounted_price,
            "savings": item_price - discounted_price,
            "reason": reason,
            "expires_in": "24 hours"
        }
    return {"eligible": False, "reason": "No discount conditions met yet"}


def get_user_behavior_summary(user_id: str) -> dict:
    """MCP Tool: Get behavior summary for a user."""
    try:
        with open(DATA_DIR / "views.json", "r") as f:
            views_data = json.load(f)
        log = views_data.get("behaviour_log", [])
        user_events = [e for e in log if e.get("user_id") == user_id]
        view_count = sum(1 for e in user_events if e.get("event") == "view")
        cart_count = sum(1 for e in user_events if e.get("event") == "cart_add")
        purchase_count = sum(1 for e in user_events if e.get("event") == "purchase")
        return {
            "user_id": user_id,
            "total_views": view_count,
            "cart_adds": cart_count,
            "purchases": purchase_count,
            "engagement_score": view_count + cart_count * 3 + purchase_count * 5,
            "intent_level": "high" if cart_count > 0 else ("medium" if view_count > 3 else "low")
        }
    except Exception:
        return {"user_id": user_id, "total_views": 0, "cart_adds": 0,
                "purchases": 0, "engagement_score": 0, "intent_level": "low"}


# ══════════════════════════════════════════════════════════
# SUPPORT MCP
# ══════════════════════════════════════════════════════════

def get_refund_status(order_id: str) -> dict:
    """MCP Tool: Get refund/order status."""
    with open(DATA_DIR / "support_tickets.json", "r") as f:
        data = json.load(f)
    for ticket in data["tickets"]:
        if ticket.get("order_id") == order_id:
            return {
                "found": True,
                "ticket": ticket,
                "refund_eligible": ticket.get("issue_type") in ["refund", "damaged"],
                "status": ticket.get("status")
            }
    # Simulate a found order
    return {
        "found": True,
        "ticket": {
            "ticket_id": f"TKT-{random.randint(100,999)}",
            "order_id": order_id,
            "status": "under_review",
            "issue_type": "refund"
        },
        "refund_eligible": True,
        "status": "under_review"
    }


def cancel_order(order_id: str, reason: str = "customer_request") -> dict:
    """MCP Tool: Cancel an order."""
    ticket_id = f"TKT-{uuid.uuid4().hex[:6].upper()}"
    return {
        "success": True,
        "order_id": order_id,
        "ticket_id": ticket_id,
        "message": f"Order {order_id} cancellation initiated.",
        "refund_eta": "3-5 business days",
        "status": "cancellation_requested"
    }


def create_support_ticket(user_id: str, issue_type: str,
                           description: str, product: str = None) -> dict:
    """MCP Tool: Create a new support ticket."""
    ticket_id = f"TKT-{uuid.uuid4().hex[:6].upper()}"
    priority = "high" if issue_type in ["refund", "damaged"] else "medium"
    return {
        "ticket_id": ticket_id,
        "user_id": user_id,
        "issue_type": issue_type,
        "product": product,
        "description": description,
        "priority": priority,
        "status": "open",
        "created_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "message": f"Ticket {ticket_id} created. Our team will respond within 24 hours.",
        "escalated_to_human": priority == "high"
    }
