# SmartCX AI — Setup Guide

## Requirements
- Python 3.9+
- pip

## Installation

```bash
pip install -r requirements.txt
```

## API Configuration
The app uses **Groq API** with **Qwen QwQ 32B** model.
The API key is pre-configured in `agents/agents.py`.

To change the key, edit `agents/agents.py`:
```python
GROQ_API_KEY = "your_groq_api_key_here"
MODEL = "qwen-qwq-32b"
```

## Run

```bash
python app.py
```

Open http://localhost:7860 in your browser.

## Architecture
- **Agent 1** — Recommendation Agent (product matching + ranking)
- **Agent 2** — Discount Agent (behavior-aware coupon generation)
- **Agent 3** — Customer Support Agent (refunds, cancellations, delivery)
- **Agent 4** — Virtual Try-On Agent (vision AI styling)
- **A2A Protocol** — Inter-agent communication layer
- **MCP Tools** — Product catalog, trend data, user behavior, support tickets

## Notes
- If Groq API is unreachable, all agents automatically fall back to template responses.
- Qwen QwQ 32B outputs `<think>` blocks which are automatically stripped before display.
- Vision try-on uses Groq's OpenAI-compatible image_url format; falls back gracefully if not supported.
